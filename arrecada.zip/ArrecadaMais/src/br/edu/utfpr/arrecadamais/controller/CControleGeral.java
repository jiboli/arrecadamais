package br.edu.utfpr.arrecadamais.controller;

public class CControleGeral {
    
    public static String formatarNumeroDouble(double numero){
        return String.format("%1$,.2f", numero);
    }
    
}
